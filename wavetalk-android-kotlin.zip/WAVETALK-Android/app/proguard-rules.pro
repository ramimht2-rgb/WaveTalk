# Keep WAVETALK audio, network, and service classes intact
-keep class com.wavetalk.radio.** { *; }
