package com.wavetalk.radio.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.wavetalk.radio.R

/**
 * Foreground microphone service required by Android 14+ to sustain
 * Push-To-Talk audio capture and local Wi-Fi multicast listening
 * while the screen is dimmed or locked.
 */
class RadioForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "wavetalk_radio_channel"
        const val NOTIFICATION_ID = 1001
        const val EXTRA_BATTERY_SAVER = "battery_saver"
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val batterySaver = intent?.getBooleanExtra(EXTRA_BATTERY_SAVER, false) ?: false
        val notification = buildNotification(batterySaver)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        manageWakeLock(batterySaver)
        return START_STICKY
    }

    private fun manageWakeLock(batterySaver: Boolean) {
        if (batterySaver) {
            if (wakeLock?.isHeld == true) wakeLock?.release()
            wakeLock = null
            return
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WaveTalk::RadioWakeLock")
        }
        if (wakeLock?.isHeld == false) {
            wakeLock?.acquire(60 * 60 * 1000L)
        }
    }

    private fun buildNotification(batterySaver: Boolean): Notification {
        val status = if (batterySaver) "Battery Saver (8kHz)" else "Active Tactical Transceiver"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID,
                "WAVETALK Radio Link",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
    }

    override fun onDestroy() {
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
