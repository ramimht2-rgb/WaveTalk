package com.wavetalk.radio.ui

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.media.MediaPlayer
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.wavetalk.radio.audio.AudioTransceiverEngine
import com.wavetalk.radio.bluetooth.BluetoothDiscoveryAndHeadsetManager
import com.wavetalk.radio.network.LocalWifiMulticastEngine
import com.wavetalk.radio.network.WifiDirectP2pManager
import com.wavetalk.radio.service.RadioForegroundService
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class RadioChannelModel(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val frequencyMhz: String,
    val isPrivate: Boolean,
    val expectedPassword: String = ""
)

data class PeerNode(
    val peerId: String,
    val callsign: String,
    val channelId: String,
    val lastSeenMs: Long
)

enum class NavTab { TRANSCEIVER, CHANNELS, HARDWARE, RECORDINGS }
enum class TransportKind { WIFI_MULTICAST, WIFI_DIRECT, BLUETOOTH }

class MainActivity : ComponentActivity() {

    private lateinit var audioEngine: AudioTransceiverEngine
    private lateinit var wifiEngine: LocalWifiMulticastEngine
    private lateinit var wifiDirect: WifiDirectP2pManager
    private lateinit var btManager: BluetoothDiscoveryAndHeadsetManager

    private val localPeerId = UUID.randomUUID().toString().take(8)
    private var activePlayer: MediaPlayer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val defaultCallsign = "UNIT-${localPeerId.take(4).uppercase()}"
        audioEngine = AudioTransceiverEngine(this)
        wifiEngine = LocalWifiMulticastEngine(this, localPeerId, defaultCallsign)
        wifiDirect = WifiDirectP2pManager(this)
        btManager = BluetoothDiscoveryAndHeadsetManager(this)

        requestRadioPermissions()
        startService(Intent(this, RadioForegroundService::class.java))

        setContent {
            var isArabic by remember { mutableStateOf(false) }
            var darkMode by remember { mutableStateOf(true) }
            val palette = if (darkMode) TacticalDarkPalette else DaylightFieldPalette

            var activeTab by remember { mutableStateOf(NavTab.TRANSCEIVER) }
            var callsign by remember { mutableStateOf(defaultCallsign) }
            var transport by remember { mutableStateOf(TransportKind.WIFI_MULTICAST) }

            val channels = remember {
                mutableStateListOf(
                    RadioChannelModel("ch-01", "CH-01 ALPHA", "القناة ٠١ ألفا", "145.500", false),
                    RadioChannelModel("ch-02", "CH-02 BRAVO", "القناة ٠٢ برافو", "146.250", false),
                    RadioChannelModel("ch-03", "CH-03 RECON", "القناة ٠٣ استطلاع", "446.000", false),
                    RadioChannelModel("ch-04", "CH-04 COMMAND", "القناة ٠٤ قيادة", "151.820", true, "1234"),
                    RadioChannelModel("ch-99", "CH-99 GUARD SOS", "القناة ٩٩ طوارئ", "121.500", false)
                )
            }
            var activeChannel by remember { mutableStateOf(channels.first()) }
            var channelPassword by remember { mutableStateOf("") }
            var unlockCandidate by remember { mutableStateOf<RadioChannelModel?>(null) }
            var unlockError by remember { mutableStateOf(false) }
            var showCreateDialog by remember { mutableStateOf(false) }

            var isTransmitting by remember { mutableStateOf(false) }
            var latchMode by remember { mutableStateOf(false) }
            var noiseCancel by remember { mutableStateOf(true) }
            var batterySaver by remember { mutableStateOf(false) }
            var autoRecord by remember { mutableStateOf(true) }
            var liveRms by remember { mutableFloatStateOf(0f) }

            var activeRxSpeaker by remember { mutableStateOf<String?>(null) }
            var sosAlertFrom by remember { mutableStateOf<String?>(null) }
            var sosArmed by remember { mutableStateOf(false) }

            val activePeers = remember { mutableStateMapOf<String, PeerNode>() }
            val btDevices = remember { mutableStateListOf<BluetoothDevice>() }
            var btHeadsetRouted by remember { mutableStateOf(false) }
            val p2pPeers = remember { mutableStateListOf<WifiP2pDevice>() }
            var p2pConnectedHost by remember { mutableStateOf<String?>(null) }
            val recordings = remember { mutableStateListOf<File>() }

            fun reloadRecordings() {
                val dir = File(filesDir, "recordings")
                val list = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
                recordings.clear()
                recordings.addAll(list)
            }

            // Initialize local Wi-Fi multicast, Wi-Fi Direct, and presence heartbeat
            LaunchedEffect(Unit) {
                reloadRecordings()
                wifiEngine.start(lifecycleScope) { packet, _ ->
                    when (packet.type) {
                        1.toByte() -> {
                            val pcm = wifiEngine.decryptIfProtected(
                                packet.payload,
                                channelPassword.ifEmpty { null }
                            )
                            if (pcm != null && packet.channelId == activeChannel.id) {
                                activeRxSpeaker = packet.senderCallsign
                                audioEngine.writeIncomingPcm(
                                    pcm,
                                    if (btHeadsetRouted) btManager.getAvailableBluetoothHeadset() else null
                                )
                            }
                        }
                        2.toByte() -> {
                            activePeers[packet.senderId] = PeerNode(
                                packet.senderId,
                                packet.senderCallsign,
                                packet.channelId,
                                System.currentTimeMillis()
                            )
                        }
                        3.toByte() -> {
                            sosAlertFrom = "${packet.senderCallsign} (${packet.channelId.uppercase()})"
                            audioEngine.playEmergencySosBeacon(lifecycleScope)
                        }
                    }
                }

                wifiDirect.initialize(
                    lifecycleScope,
                    onPeersUpdated = { list ->
                        p2pPeers.clear()
                        p2pPeers.addAll(list)
                    },
                    onConnectionChanged = { connected, host ->
                        p2pConnectedHost = if (connected) host ?: "CONNECTED" else null
                    },
                    onAudioFrame = { pcm ->
                        audioEngine.writeIncomingPcm(
                            pcm,
                            if (btHeadsetRouted) btManager.getAvailableBluetoothHeadset() else null
                        )
                    }
                )

                while (isActive) {
                    wifiEngine.sendPacket(2, activeChannel.id, ByteArray(0))
                    val cutoff = System.currentTimeMillis() - 12000L
                    activePeers.entries.removeAll { it.value.lastSeenMs < cutoff }
                    delay(if (batterySaver) 5000L else 2500L)
                }
            }

            fun beginTx() {
                if (isTransmitting) return
                isTransmitting = true
                audioEngine.noiseCancellationEnabled = noiseCancel
                audioEngine.batterySaverEnabled = batterySaver
                audioEngine.startLiveTransmission(lifecycleScope, autoRecord) { pcm, rms ->
                    liveRms = rms
                    if (transport == TransportKind.WIFI_DIRECT && p2pConnectedHost != null) {
                        wifiDirect.sendP2pAudio(pcm)
                    } else {
                        wifiEngine.sendPacket(
                            1,
                            activeChannel.id,
                            pcm,
                            channelPassword.ifEmpty { null }
                        )
                    }
                }
            }

            fun endTx() {
                if (!isTransmitting) return
                isTransmitting = false
                liveRms = 0f
                audioEngine.stopTransmission()
                reloadRecordings()
            }

            CompositionLocalProvider(
                LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
            ) {
                Scaffold(
                    containerColor = palette.background,
                    topBar = {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.background)
                                .border(1.dp, palette.border)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isArabic) "ويف توك" else "WAVETALK",
                                color = palette.amber,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { isArabic = !isArabic }) {
                                    Text(
                                        if (isArabic) "EN" else "عربي",
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                IconButton(onClick = { darkMode = !darkMode }) {
                                    Icon(
                                        if (darkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                                        contentDescription = null,
                                        tint = palette.amber
                                    )
                                }
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = palette.surface) {
                            NavigationBarItem(
                                selected = activeTab == NavTab.TRANSCEIVER,
                                onClick = { activeTab = NavTab.TRANSCEIVER },
                                icon = { Icon(Icons.Default.Mic, contentDescription = null) },
                                label = { Text(if (isArabic) "اللاسلكي" else "Radio", fontSize = 11.sp) }
                            )
                            NavigationBarItem(
                                selected = activeTab == NavTab.CHANNELS,
                                onClick = { activeTab = NavTab.CHANNELS },
                                icon = { Icon(Icons.Default.List, contentDescription = null) },
                                label = { Text(if (isArabic) "القنوات" else "Channels", fontSize = 11.sp) }
                            )
                            NavigationBarItem(
                                selected = activeTab == NavTab.HARDWARE,
                                onClick = { activeTab = NavTab.HARDWARE },
                                icon = { Icon(Icons.Default.Bluetooth, contentDescription = null) },
                                label = { Text(if (isArabic) "العتاد" else "Hardware", fontSize = 11.sp) }
                            )
                            NavigationBarItem(
                                selected = activeTab == NavTab.RECORDINGS,
                                onClick = {
                                    reloadRecordings()
                                    activeTab = NavTab.RECORDINGS
                                },
                                icon = { Icon(Icons.Default.GraphicEq, contentDescription = null) },
                                label = { Text(if (isArabic) "التسجيلات" else "Clips", fontSize = 11.sp) }
                            )
                        }
                    }
                ) { padding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .padding(16.dp)
                    ) {
                        if (sosAlertFrom != null) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.txCrimson)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = (if (isArabic) "طوارئ SOS: " else "SOS ALERT: ") + sosAlertFrom,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                TextButton(onClick = { sosAlertFrom = null }) {
                                    Text(if (isArabic) "إلغاء" else "CLEAR", color = Color.White)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                        }

                        when (activeTab) {
                            NavTab.TRANSCEIVER -> {
                                // Recessed LCD Readout
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(palette.lcdSurface)
                                        .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                                        .padding(16.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = if (isArabic) activeChannel.nameAr else activeChannel.name,
                                            color = palette.amber,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${activePeers.size + 1} " + (if (isArabic) "وحدة" else "UNITS"),
                                            color = palette.signalGreen,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = "${activeChannel.frequencyMhz} MHz",
                                        color = palette.amber,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = { if (isTransmitting) liveRms.coerceIn(0.05f, 1f) else 0.05f },
                                        modifier = Modifier.fillMaxWidth().height(6.dp),
                                        color = if (isTransmitting) palette.txCrimson else palette.signalGreen,
                                        trackColor = palette.border
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = when {
                                                isTransmitting -> if (isArabic) "إرسال مباشر: $callsign" else "TX LIVE: $callsign"
                                                activeRxSpeaker != null -> (if (isArabic) "استقبال: " else "RX: ") + activeRxSpeaker
                                                else -> if (isArabic) "وضع الاستعداد" else "STANDBY"
                                            },
                                            color = if (isTransmitting) palette.txCrimson else palette.signalGreen,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = if (batterySaver) "8kHz ECO" else "16kHz PCM",
                                            color = palette.textSecondary,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                // Giant Machined Tactical PTT Button
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(224.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.verticalGradient(
                                                    if (isTransmitting)
                                                        listOf(Color(0xFFDC2626), Color(0xFF7F1D1D))
                                                    else
                                                        listOf(Color(0xFF1E2630), Color(0xFF0F1419))
                                                )
                                            )
                                            .border(
                                                4.dp,
                                                if (isTransmitting) palette.txCrimson else palette.amber,
                                                CircleShape
                                            )
                                            .pointerInput(latchMode, activeChannel, channelPassword, noiseCancel, batterySaver) {
                                                detectTapGestures(
                                                    onPress = {
                                                        if (latchMode) {
                                                            if (isTransmitting) endTx() else beginTx()
                                                        } else {
                                                            beginTx()
                                                            tryAwaitRelease()
                                                            endTx()
                                                        }
                                                    }
                                                )
                                            }
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                Icons.Default.Mic,
                                                contentDescription = null,
                                                tint = if (isTransmitting) Color.White else palette.amber,
                                                modifier = Modifier.size(44.dp)
                                            )
                                            Spacer(Modifier.height(8.dp))
                                            Text(
                                                text = when {
                                                    isTransmitting && latchMode -> if (isArabic) "قفل الإرسال" else "LATCH TX ON"
                                                    isTransmitting -> if (isArabic) "جاري الإرسال" else "TRANSMITTING"
                                                    else -> if (isArabic) "اضغط للتحدث" else "HOLD TO TALK"
                                                },
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 18.sp,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }

                                // Tactical Controls Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterChip(
                                        selected = noiseCancel,
                                        onClick = {
                                            noiseCancel = !noiseCancel
                                            audioEngine.noiseCancellationEnabled = noiseCancel
                                        },
                                        label = { Text(if (isArabic) "عزل ضوضاء" else "DSP NC", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    FilterChip(
                                        selected = batterySaver,
                                        onClick = {
                                            batterySaver = !batterySaver
                                            audioEngine.batterySaverEnabled = batterySaver
                                            startService(
                                                Intent(this@MainActivity, RadioForegroundService::class.java)
                                                    .putExtra(RadioForegroundService.EXTRA_BATTERY_SAVER, batterySaver)
                                            )
                                        },
                                        label = { Text(if (isArabic) "توفير طاقة" else "ECO", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    FilterChip(
                                        selected = latchMode,
                                        onClick = { latchMode = !latchMode },
                                        label = { Text(if (isArabic) "تثبيت" else "LATCH", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        colors = ButtonDefaults.buttonColors(containerColor = palette.txCrimson),
                                        onClick = {
                                            if (!sosArmed) {
                                                sosArmed = true
                                                lifecycleScope.launch {
                                                    delay(3000)
                                                    sosArmed = false
                                                }
                                            } else {
                                                sosArmed = false
                                                sosAlertFrom = "$callsign (${activeChannel.id.uppercase()})"
                                                wifiEngine.sendPacket(3, activeChannel.id, "SOS".toByteArray())
                                                audioEngine.playEmergencySosBeacon(lifecycleScope)
                                            }
                                        }
                                    ) {
                                        Text(
                                            if (sosArmed) (if (isArabic) "تأكيد" else "CONFIRM") else "SOS",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            NavTab.CHANNELS -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isArabic) "قنوات الراديو" else "Radio Channels",
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Button(onClick = { showCreateDialog = true }) {
                                        Text(if (isArabic) "قناة جديدة" else "New Channel")
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(channels) { ch ->
                                        val selected = ch.id == activeChannel.id
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(palette.surface)
                                                .border(
                                                    1.dp,
                                                    if (selected) palette.amber else palette.border,
                                                    RoundedCornerShape(10.dp)
                                                )
                                                .clickable {
                                                    if (ch.isPrivate && ch.id != activeChannel.id) {
                                                        unlockError = false
                                                        unlockCandidate = ch
                                                    } else {
                                                        channelPassword = ""
                                                        activeChannel = ch
                                                    }
                                                }
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = if (isArabic) ch.nameAr else ch.name,
                                                    color = if (selected) palette.amber else palette.textPrimary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${ch.frequencyMhz} MHz",
                                                    color = palette.textSecondary,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 12.sp
                                                )
                                            }
                                            if (ch.isPrivate) {
                                                Icon(Icons.Default.Lock, contentDescription = null, tint = palette.amber)
                                            }
                                        }
                                    }
                                }
                            }

                            NavTab.HARDWARE -> {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    item {
                                        Text(
                                            text = if (isArabic) "ناقل الاتصال والعتاد" else "Transport & Wireless Hardware",
                                            color = palette.textPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                    }
                                    item {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TransportKind.entries.forEach { kind ->
                                                FilterChip(
                                                    selected = transport == kind,
                                                    onClick = { transport = kind },
                                                    label = {
                                                        Text(
                                                            when (kind) {
                                                                TransportKind.WIFI_MULTICAST -> "Wi-Fi LAN"
                                                                TransportKind.WIFI_DIRECT -> "Wi-Fi Direct"
                                                                TransportKind.BLUETOOTH -> "Bluetooth"
                                                            },
                                                            fontSize = 11.sp
                                                        )
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    item {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = {
                                                wifiDirect.discoverPeers {}
                                            }) {
                                                Text(if (isArabic) "فحص Wi-Fi Direct" else "Scan Wi-Fi Direct", fontSize = 12.sp)
                                            }
                                            Button(onClick = {
                                                btManager.startDiscovery { found ->
                                                    btDevices.clear()
                                                    btDevices.addAll(found)
                                                }
                                            }) {
                                                Text(if (isArabic) "فحص بلوتوث" else "Scan Bluetooth", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                    item {
                                        FilterChip(
                                            selected = btHeadsetRouted,
                                            onClick = {
                                                val next = !btHeadsetRouted
                                                if (btManager.setBluetoothHeadsetRouting(next)) {
                                                    btHeadsetRouted = next
                                                }
                                            },
                                            label = {
                                                Text(if (isArabic) "توجيه سماعة البلوتوث (SCO)" else "Route Bluetooth Headset (SCO)")
                                            }
                                        )
                                    }
                                    items(p2pPeers) { dev ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(palette.surface)
                                                .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                                                .clickable { wifiDirect.connectToPeer(dev.deviceAddress) {} }
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(dev.deviceName ?: dev.deviceAddress, color = palette.textPrimary)
                                            Text("P2P CONNECT", color = palette.amber, fontSize = 12.sp)
                                        }
                                    }
                                    items(btDevices) { dev ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(palette.surface)
                                                .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(dev.name ?: dev.address, color = palette.textPrimary)
                                            Text(dev.address, color = palette.textSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }

                            NavTab.RECORDINGS -> {
                                Text(
                                    text = if (isArabic) "التسجيلات الصوتية" else "Voice Recordings",
                                    color = palette.textPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(Modifier.height(12.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(recordings) { file ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(palette.surface)
                                                .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(file.name, color = palette.textPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                                Text("${file.length() / 1024} KB", color = palette.textSecondary, fontSize = 11.sp)
                                            }
                                            Row {
                                                IconButton(onClick = {
                                                    activePlayer?.release()
                                                    activePlayer = MediaPlayer().apply {
                                                        setDataSource(file.absolutePath)
                                                        prepare()
                                                        start()
                                                    }
                                                }) {
                                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = palette.signalGreen)
                                                }
                                                IconButton(onClick = {
                                                    file.delete()
                                                    reloadRecordings()
                                                }) {
                                                    Icon(Icons.Default.Delete, contentDescription = null, tint = palette.txCrimson)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Private Channel Password Dialog
                    unlockCandidate?.let { target ->
                        var pwInput by remember { mutableStateOf("") }
                        AlertDialog(
                            onDismissRequest = { unlockCandidate = null },
                            title = { Text(if (isArabic) "كلمة مرور القناة" else "Private Channel Password") },
                            text = {
                                Column {
                                    Text(if (isArabic) "رمز التجربة لـ CH-04: 1234" else "Default pin for CH-04: 1234", fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = pwInput,
                                        onValueChange = { pwInput = it },
                                        visualTransformation = PasswordVisualTransformation(),
                                        singleLine = true
                                    )
                                    if (unlockError) {
                                        Text(
                                            if (isArabic) "كلمة المرور غير صحيحة" else "Invalid password",
                                            color = palette.txCrimson,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    if (target.expectedPassword.isEmpty() || pwInput == target.expectedPassword) {
                                        channelPassword = pwInput
                                        activeChannel = target
                                        unlockCandidate = null
                                        unlockError = false
                                    } else {
                                        unlockError = true
                                    }
                                }) {
                                    Text(if (isArabic) "فتح" else "Unlock")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { unlockCandidate = null }) {
                                    Text(if (isArabic) "إلغاء" else "Cancel")
                                }
                            }
                        )
                    }

                    // Create Channel Dialog
                    if (showCreateDialog) {
                        var chName by remember { mutableStateOf("") }
                        var chFreq by remember { mutableStateOf("446.125") }
                        var chPass by remember { mutableStateOf("") }
                        AlertDialog(
                            onDismissRequest = { showCreateDialog = false },
                            title = { Text(if (isArabic) "إنشاء قناة جديدة" else "Create Channel") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = chName, onValueChange = { chName = it }, label = { Text("Name") })
                                    OutlinedTextField(value = chFreq, onValueChange = { chFreq = it }, label = { Text("MHz") })
                                    OutlinedTextField(
                                        value = chPass,
                                        onValueChange = { chPass = it },
                                        label = { Text("Password (optional)") },
                                        visualTransformation = PasswordVisualTransformation()
                                    )
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    if (chName.isNotBlank()) {
                                        val created = RadioChannelModel(
                                            id = "ch-${UUID.randomUUID().toString().take(4)}",
                                            nameEn = chName.trim().uppercase(),
                                            nameAr = chName.trim(),
                                            frequencyMhz = chFreq.ifBlank { "446.125" },
                                            isPrivate = chPass.isNotEmpty(),
                                            expectedPassword = chPass
                                        )
                                        channels.add(created)
                                        channelPassword = chPass
                                        activeChannel = created
                                        showCreateDialog = false
                                    }
                                }) {
                                    Text(if (isArabic) "إنشاء" else "Create")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showCreateDialog = false }) {
                                    Text(if (isArabic) "إلغاء" else "Cancel")
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    private fun requestRadioPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        activePlayer?.release()
        audioEngine.release()
        wifiEngine.stop()
        wifiDirect.release()
        btManager.release()
    }
}
