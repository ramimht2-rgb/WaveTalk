package com.wavetalk.radio.network

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Wi-Fi Direct (P2P) manager for infrastructure-less phone-to-phone radio links
 * when no Wi-Fi router or hotspot is available.
 */
class WifiDirectP2pManager(private val context: Context) {

    private val manager = context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager?
    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private var p2pSocket: Socket? = null
    private var serverSocket: ServerSocket? = null
    private var outputStream: OutputStream? = null

    fun initialize(
        scope: CoroutineScope,
        onPeersUpdated: (List<WifiP2pDevice>) -> Unit,
        onConnectionChanged: (Boolean, String?) -> Unit,
        onAudioFrame: (ByteArray) -> Unit
    ) {
        val mgr = manager ?: return
        channel = mgr.initialize(context, context.mainLooper, null)

        val intentFilter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }

        receiver = object : BroadcastReceiver() {
            @SuppressLint("MissingPermission")
            override fun onReceive(ctx: Context, intent: Intent) {
                when (intent.action) {
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                        mgr.requestPeers(channel) { list ->
                            onPeersUpdated(list.deviceList.toList())
                        }
                    }
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                        @Suppress("DEPRECATION")
                        val networkInfo = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                        if (networkInfo?.isConnected == true) {
                            mgr.requestConnectionInfo(channel) { info ->
                                val host = info.groupOwnerAddress?.hostAddress
                                onConnectionChanged(true, host)
                                if (info.groupFormed && info.isGroupOwner) {
                                    startGroupOwnerServer(scope, onAudioFrame)
                                } else if (info.groupFormed && host != null) {
                                    connectToGroupOwner(scope, host, onAudioFrame)
                                }
                            }
                        } else {
                            onConnectionChanged(false, null)
                        }
                    }
                }
            }
        }
        context.registerReceiver(receiver, intentFilter)
    }

    @SuppressLint("MissingPermission")
    fun discoverPeers(onError: (Int) -> Unit) {
        val mgr = manager ?: return
        val ch = channel ?: return
        mgr.discoverPeers(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(reason: Int) { onError(reason) }
        })
    }

    @SuppressLint("MissingPermission")
    fun connectToPeer(deviceAddress: String, onError: (Int) -> Unit) {
        val mgr = manager ?: return
        val ch = channel ?: return
        val config = WifiP2pConfig().apply { this.deviceAddress = deviceAddress }
        mgr.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(reason: Int) { onError(reason) }
        })
    }

    private fun startGroupOwnerServer(scope: CoroutineScope, onAudioFrame: (ByteArray) -> Unit) {
        scope.launch(Dispatchers.IO) {
            serverSocket = ServerSocket(50888)
            val client = serverSocket?.accept() ?: return@launch
            p2pSocket = client
            outputStream = client.getOutputStream()
            readLoop(client.getInputStream(), onAudioFrame)
        }
    }

    private fun connectToGroupOwner(scope: CoroutineScope, host: String, onAudioFrame: (ByteArray) -> Unit) {
        scope.launch(Dispatchers.IO) {
            val sock = Socket()
            sock.connect(InetSocketAddress(host, 50888), 5000)
            p2pSocket = sock
            outputStream = sock.getOutputStream()
            readLoop(sock.getInputStream(), onAudioFrame)
        }
    }

    private fun readLoop(input: InputStream, onAudioFrame: (ByteArray) -> Unit) {
        val buf = ByteArray(2048)
        while (true) {
            val read = input.read(buf)
            if (read <= 0) break
            onAudioFrame(buf.copyOf(read))
        }
    }

    fun sendP2pAudio(pcm: ByteArray) {
        try {
            outputStream?.write(pcm)
        } catch (_: Exception) {}
    }

    fun release() {
        receiver?.let { try { context.unregisterReceiver(it) } catch (_: Exception) {} }
        try { p2pSocket?.close(); serverSocket?.close() } catch (_: Exception) {}
    }
}
