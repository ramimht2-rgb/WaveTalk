package com.wavetalk.radio.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import java.net.*
import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Offline Local Wi-Fi Transceiver using UDP Multicast + Android NsdManager.
 * Requires ZERO internet connection and ZERO cloud servers.
 * Private channels derive an AES-256-GCM key from the shared channel passphrase.
 */
class LocalWifiMulticastEngine(
    private val context: Context,
    private val localPeerId: String,
    private val callsign: String
) {
    companion object {
        const val MULTICAST_GROUP = "239.255.77.88"
        const val PORT = 50777
        const val NSD_TYPE = "_wavetalk._udp."
    }

    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var multicastLock: WifiManager.MulticastLock? = null
    private var socket: MulticastSocket? = null
    private var rxJob: Job? = null
    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var registrationListener: NsdManager.RegistrationListener? = null

    data class RadioPacket(
        val type: Byte, // 1=AUDIO, 2=PRESENCE, 3=SOS
        val channelId: String,
        val senderId: String,
        val senderCallsign: String,
        val payload: ByteArray
    )

    fun start(
        scope: CoroutineScope,
        onPacketReceived: (RadioPacket, InetAddress) -> Unit
    ) {
        stop()
        multicastLock = wifiManager.createMulticastLock("WaveTalkMulticastLock").apply {
            setReferenceCounted(true)
            acquire()
        }

        val group = InetAddress.getByName(MULTICAST_GROUP)
        val ms = MulticastSocket(PORT).apply {
            reuseAddress = true
            timeToLive = 4
            joinGroup(group)
        }
        socket = ms
        registerNsdService()

        rxJob = scope.launch(Dispatchers.IO) {
            val buf = ByteArray(4096)
            while (isActive) {
                try {
                    val datagram = DatagramPacket(buf, buf.size)
                    ms.receive(datagram)
                    val parsed = decodePacket(datagram.data, datagram.length) ?: continue
                    if (parsed.senderId != localPeerId) {
                        onPacketReceived(parsed, datagram.address)
                    }
                } catch (_: Exception) {
                    if (!isActive) break
                }
            }
        }
    }

    fun sendPacket(
        type: Byte,
        channelId: String,
        payload: ByteArray,
        channelPassword: String? = null
    ) {
        val ms = socket ?: return
        val wirePayload = if (!channelPassword.isNullOrEmpty() && type == 1.toByte()) {
            encryptAesGcm(payload, channelPassword)
        } else {
            payload
        }

        val chBytes = channelId.toByteArray(Charsets.UTF_8)
        val idBytes = localPeerId.toByteArray(Charsets.UTF_8)
        val csBytes = callsign.toByteArray(Charsets.UTF_8)

        val out = ByteBuffer.allocate(7 + chBytes.size + idBytes.size + csBytes.size + wirePayload.size)
        out.put(type)
        out.putShort(chBytes.size.toShort()).put(chBytes)
        out.putShort(idBytes.size.toShort()).put(idBytes)
        out.putShort(csBytes.size.toShort()).put(csBytes)
        out.put(wirePayload)

        val data = out.array()
        val group = InetAddress.getByName(MULTICAST_GROUP)
        ms.send(DatagramPacket(data, data.size, group, PORT))
    }

    fun decryptIfProtected(payload: ByteArray, password: String?): ByteArray? {
        if (password.isNullOrEmpty()) return payload
        return try {
            val iv = payload.copyOfRange(0, 12)
            val cipherText = payload.copyOfRange(12, payload.size)
            val key = deriveAesKey(password)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            cipher.doFinal(cipherText)
        } catch (_: Exception) {
            null
        }
    }

    private fun encryptAesGcm(plain: ByteArray, password: String): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveAesKey(password))
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain)
        return iv + encrypted
    }

    private fun deriveAesKey(password: String): SecretKeySpec {
        val hash = MessageDigest.getInstance("SHA-256").digest(password.toByteArray(Charsets.UTF_8))
        return SecretKeySpec(hash, "AES")
    }

    private fun decodePacket(raw: ByteArray, len: Int): RadioPacket? {
        if (len < 7) return null
        val buf = ByteBuffer.wrap(raw, 0, len)
        val type = buf.get()
        val chLen = buf.short.toInt(); val ch = ByteArray(chLen); buf.get(ch)
        val idLen = buf.short.toInt(); val id = ByteArray(idLen); buf.get(id)
        val csLen = buf.short.toInt(); val cs = ByteArray(csLen); buf.get(cs)
        val rem = ByteArray(buf.remaining()); buf.get(rem)
        return RadioPacket(type, String(ch), String(id), String(cs), rem)
    }

    private fun registerNsdService() {
        val info = NsdServiceInfo().apply {
            serviceName = "WAVETALK-$callsign"
            serviceType = NSD_TYPE
            port = PORT
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {}
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }
        registrationListener = listener
        nsdManager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    fun stop() {
        rxJob?.cancel(); rxJob = null
        registrationListener?.let {
            try { nsdManager.unregisterService(it) } catch (_: Exception) {}
        }
        registrationListener = null
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        if (multicastLock?.isHeld == true) multicastLock?.release()
        multicastLock = null
    }
}
