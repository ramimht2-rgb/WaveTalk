package com.wavetalk.radio.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin

/**
 * Hardware-backed PCM audio transceiver with Android NoiseSuppressor,
 * AcousticEchoCanceler, battery-saver sample rate switching (16kHz vs 8kHz),
 * WAV voice recording, and ITU Emergency SOS beacon tone synthesis.
 */
class AudioTransceiverEngine(private val context: Context) {

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var gainControl: AutomaticGainControl? = null

    private var txJob: Job? = null
    private var wavOut: FileOutputStream? = null
    private var currentRecordingFile: File? = null
    private var recordedBytes = 0

    @Volatile
    var noiseCancellationEnabled: Boolean = true

    @Volatile
    var batterySaverEnabled: Boolean = false

    val sampleRate: Int
        get() = if (batterySaverEnabled) 8000 else 16000

    private val channelIn = AudioFormat.CHANNEL_IN_MONO
    private val channelOut = AudioFormat.CHANNEL_OUT_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT

    @SuppressLint("MissingPermission")
    fun startLiveTransmission(
        scope: CoroutineScope,
        recordTransmission: Boolean,
        onPcmFrame: (ByteArray, Float) -> Unit
    ) {
        stopTransmission()
        val rate = sampleRate
        val minBuf = AudioRecord.getMinBufferSize(rate, channelIn, encoding)
        val frameSize = (rate / 50) * 2 // 20ms PCM16 mono frame

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            rate,
            channelIn,
            encoding,
            maxOf(minBuf, frameSize * 4)
        )
        audioRecord = recorder

        val sessionId = recorder.audioSessionId
        if (noiseCancellationEnabled && NoiseSuppressor.isAvailable()) {
            noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
        }
        if (AcousticEchoCanceler.isAvailable()) {
            echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
        }
        if (AutomaticGainControl.isAvailable()) {
            gainControl = AutomaticGainControl.create(sessionId)?.apply { enabled = true }
        }

        if (recordTransmission) {
            beginWavRecording(rate)
        }

        recorder.startRecording()
        txJob = scope.launch(Dispatchers.IO) {
            val buffer = ByteArray(frameSize)
            while (isActive && recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val copy = buffer.copyOf(read)
                    val rms = computeRmsLevel(copy)
                    wavOut?.write(copy)
                    recordedBytes += read
                    onPcmFrame(copy, rms)
                }
            }
        }
    }

    fun stopTransmission() {
        txJob?.cancel()
        txJob = null
        try {
            audioRecord?.stop()
        } catch (_: IllegalStateException) { }
        noiseSuppressor?.release(); noiseSuppressor = null
        echoCanceler?.release(); echoCanceler = null
        gainControl?.release(); gainControl = null
        audioRecord?.release(); audioRecord = null
        finishWavRecording()
    }

    fun ensurePlaybackTrack(preferredDevice: AudioDeviceInfo? = null) {
        if (audioTrack != null) return
        val rate = sampleRate
        val minBuf = AudioTrack.getMinBufferSize(rate, channelOut, encoding)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(rate)
                    .setChannelMask(channelOut)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        preferredDevice?.let { track.preferredDevice = it }
        track.play()
        audioTrack = track
    }

    fun writeIncomingPcm(pcmData: ByteArray, preferredDevice: AudioDeviceInfo? = null) {
        ensurePlaybackTrack(preferredDevice)
        audioTrack?.write(pcmData, 0, pcmData.size)
    }

    fun playEmergencySosBeacon(scope: CoroutineScope) {
        scope.launch(Dispatchers.IO) {
            ensurePlaybackTrack()
            val rate = sampleRate
            val samples = ByteArray(rate) // 500ms at PCM16
            val buf = ByteBuffer.wrap(samples).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until rate / 2) {
                val freq = if ((i / (rate / 8)) % 2 == 0) 960.0 else 1320.0
                val sample = (sin(2.0 * Math.PI * freq * i / rate) * 24000).toInt().toShort()
                buf.putShort(sample)
            }
            audioTrack?.write(samples, 0, samples.size)
        }
    }

    private fun beginWavRecording(rate: Int) {
        val dir = File(context.filesDir, "recordings").apply { mkdirs() }
        val file = File(dir, "WT_${System.currentTimeMillis()}.wav")
        currentRecordingFile = file
        recordedBytes = 0
        wavOut = FileOutputStream(file).apply {
            write(ByteArray(44)) // Placeholder WAV header
        }
    }

    private fun finishWavRecording(): File? {
        val out = wavOut ?: return null
        val file = currentRecordingFile ?: return null
        out.flush()
        out.close()
        wavOut = null
        writeWavHeader(file, sampleRate, recordedBytes)
        return file
    }

    private fun writeWavHeader(file: File, rate: Int, totalAudioLen: Int) {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        val byteRate = rate * 2
        header.put("RIFF".toByteArray())
        header.putInt(totalAudioLen + 36)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1)
        header.putShort(1)
        header.putInt(rate)
        header.putInt(byteRate)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray())
        header.putInt(totalAudioLen)
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.write(header.array())
        }
    }

    private fun computeRmsLevel(pcm: ByteArray): Float {
        var sum = 0.0
        var i = 0
        while (i + 1 < pcm.size) {
            val sample = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toDouble()
            sum += sample * sample
            i += 2
        }
        val count = (pcm.size / 2).coerceAtLeast(1)
        return (kotlin.math.sqrt(sum / count) / 32768.0).toFloat().coerceIn(0f, 1f)
    }

    fun release() {
        stopTransmission()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }
}
