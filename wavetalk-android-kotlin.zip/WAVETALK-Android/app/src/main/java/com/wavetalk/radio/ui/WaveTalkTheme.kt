package com.wavetalk.radio.ui

import androidx.compose.ui.graphics.Color

data class WaveTalkPalette(
    val background: Color,
    val surface: Color,
    val lcdSurface: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val amber: Color,
    val signalGreen: Color,
    val txCrimson: Color
)

val TacticalDarkPalette = WaveTalkPalette(
    background = Color(0xFF0B0E11),
    surface = Color(0xFF14191F),
    lcdSurface = Color(0xFF0F1419),
    border = Color(0xFF242D38),
    textPrimary = Color(0xFFF1F5F9),
    textSecondary = Color(0xFF94A3B8),
    amber = Color(0xFFF59E0B),
    signalGreen = Color(0xFF22C55E),
    txCrimson = Color(0xFFEF4444)
)

val DaylightFieldPalette = WaveTalkPalette(
    background = Color(0xFFF2F3EE),
    surface = Color(0xFFFFFFFF),
    lcdSurface = Color(0xFFE8EAE3),
    border = Color(0xFFCBD5E1),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF475569),
    amber = Color(0xFFD97706),
    signalGreen = Color(0xFF16A34A),
    txCrimson = Color(0xFFDC2626)
)
