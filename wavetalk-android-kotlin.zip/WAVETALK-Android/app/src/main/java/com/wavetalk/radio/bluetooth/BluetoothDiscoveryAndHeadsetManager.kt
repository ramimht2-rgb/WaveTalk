package com.wavetalk.radio.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/**
 * Handles real Android Bluetooth Classic/BLE device discovery and
 * Bluetooth SCO / BLE Headset audio routing via AudioManager.
 */
class BluetoothDiscoveryAndHeadsetManager(private val context: Context) {

    private val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?
    private val btAdapter: BluetoothAdapter? = btManager?.adapter
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var discoveryReceiver: BroadcastReceiver? = null
    private val discoveredDevices = LinkedHashMap<String, BluetoothDevice>()

    @SuppressLint("MissingPermission")
    fun startDiscovery(onDevicesUpdated: (List<BluetoothDevice>) -> Unit) {
        val adapter = btAdapter ?: return
        discoveredDevices.clear()
        adapter.bondedDevices?.forEach { discoveredDevices[it.address] = it }
        onDevicesUpdated(discoveredDevices.values.toList())

        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        discoveryReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (BluetoothDevice.ACTION_FOUND == intent.action) {
                    @Suppress("DEPRECATION")
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    if (device != null) {
                        discoveredDevices[device.address] = device
                        onDevicesUpdated(discoveredDevices.values.toList())
                    }
                }
            }
        }
        context.registerReceiver(discoveryReceiver, filter)
        if (adapter.isDiscovering) adapter.cancelDiscovery()
        adapter.startDiscovery()
    }

    fun getAvailableBluetoothHeadset(): AudioDeviceInfo? {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
    }

    @Suppress("DEPRECATION")
    fun setBluetoothHeadsetRouting(enabled: Boolean): Boolean {
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            if (enabled) {
                val commDevices = audioManager.availableCommunicationDevices
                val btDevice = commDevices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                } ?: return false
                return audioManager.setCommunicationDevice(btDevice)
            } else {
                audioManager.clearCommunicationDevice()
                return true
            }
        } else {
            if (enabled) {
                audioManager.startBluetoothSco()
                audioManager.isBluetoothScoOn = true
            } else {
                audioManager.stopBluetoothSco()
                audioManager.isBluetoothScoOn = false
            }
            return true
        }
    }

    @SuppressLint("MissingPermission")
    fun release() {
        btAdapter?.cancelDiscovery()
        discoveryReceiver?.let { try { context.unregisterReceiver(it) } catch (_: Exception) {} }
        setBluetoothHeadsetRouting(false)
    }
}
